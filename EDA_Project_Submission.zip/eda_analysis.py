
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("customer_data.csv")
print(df.describe())
print(df.corr(numeric_only=True))

df.hist(figsize=(8,4))
plt.show()
